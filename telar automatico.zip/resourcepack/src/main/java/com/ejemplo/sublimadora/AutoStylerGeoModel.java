package com.ejemplo.sublimadora;

import net.minecraft.util.Identifier;
import software.bernie.geckolib.model.GeoModel;

public class AutoStylerGeoModel extends GeoModel<AutoStylerBlockEntity> {
    private static final Identifier GEO = Identifier.of("sublimadora", "geo/auto_styler.geo.json");
    private static final Identifier TEX = Identifier.of("sublimadora", "textures/block/auto_styler_atlas.png");
    private static final Identifier ANIM = Identifier.of("sublimadora", "animations/auto_styler.animation.json");

    @Override public Identifier getModelResource(AutoStylerBlockEntity be) { return GEO; }
    @Override public Identifier getTextureResource(AutoStylerBlockEntity be) { return TEX; }
    @Override public Identifier getAnimationResource(AutoStylerBlockEntity be) { return ANIM; }
}
