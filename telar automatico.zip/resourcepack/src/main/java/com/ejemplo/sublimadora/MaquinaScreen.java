package com.ejemplo.sublimadora;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/**
 * Pantalla base: dibuja el fondo (una textura por maquina, 256x256) y encima
 * lo que cambia — previsualizacion, testigos, progreso y niveles.
 * Todo lo dinamico se pinta con fill(), no con sprites: los colores son los
 * mismos del bloque, asi la GUI no se despega del frente.
 */
public abstract class MaquinaScreen<T extends MaquinaScreenHandler> extends HandledScreen<T> {

    // cotas (ver GUI-SPEC.md)
    protected static final int PREVIEW_X = 10, PREVIEW_Y = 20, TESELA_ANCHO = 20, TESELA_ALTO = 33;
    protected static final int BARRA_Y = 41, BARRA_ALTO = 28, BARRA_ANCHO = 10;
    protected static final int[] BARRA_X = { 80, 98, 116, 134, 152 };
    protected static final int PROGRESO_Y = 24, PROGRESO_ALTO = 8;

    // paleta compartida con el atlas del bloque
    protected static final int CYAN = 0xFF34C6D8, MAGENTA = 0xFFD13A86, AMARILLO = 0xFFE8C53A,
            NEGRO = 0xFF17171A, PAPEL = 0xFFE7E2D4;
    protected static final int[] TINTA = { CYAN, MAGENTA, AMARILLO, NEGRO, PAPEL };
    /** indice de tesela -> color; el orden es el de atlas-orden.json */
    protected static final int[] PALETA = { CYAN, MAGENTA, AMARILLO, NEGRO, PAPEL,
            0xFFB06A3F, 0xFF4E8C78, 0xFFB68235, 0xFF63676F, 0xFF15161B };

    protected MaquinaScreen(T handler, PlayerInventory jugador, Text titulo) {
        super(handler, jugador, titulo);
        backgroundWidth = 176;
        backgroundHeight = 186;
        playerInventoryTitleY = backgroundHeight - 94;   // 92
    }

    @Override
    protected void init() {
        super.init();
        titleX = 8;
        titleY = 5;
    }

    protected abstract Identifier textura();
    protected abstract int acento();
    /** cuantas barras verticales dibuja: 0 shaper · 4 dye · 5 sublimator (la 5a es papel) */
    protected abstract int canales();
    protected abstract int progresoX();
    protected abstract int progresoAncho();

    @Override
    protected void drawBackground(DrawContext ctx, float delta, int mouseX, int mouseY) {
        int x = (width - backgroundWidth) / 2;
        int y = (height - backgroundHeight) / 2;
        ctx.drawTexture(textura(), x, y, 0, 0, backgroundWidth, backgroundHeight);
        dibujarDiseno(ctx, x, y);
        dibujarProgreso(ctx, x, y);
        dibujarNiveles(ctx, x, y);
    }

    /** Las 6 teselas del hueso design, en grande. Sin produccion todavia: fantasma al 20 %. */
    private void dibujarDiseno(DrawContext ctx, int x, int y) {
        boolean fantasma = handler.disenoVacio();
        for (int i = 0; i < 6; i++) {
            int indice = handler.getTesela(i);
            int color = indice < 0 || indice >= PALETA.length ? PALETA[i % PALETA.length] : PALETA[indice];
            if (fantasma) color = (color & 0x00FFFFFF) | 0x33000000;
            int cx = x + PREVIEW_X + (i % 3) * TESELA_ANCHO;
            int cy = y + PREVIEW_Y + (i / 3) * TESELA_ALTO;
            ctx.fill(cx, cy, cx + TESELA_ANCHO, cy + TESELA_ALTO, color);
        }
    }

    private void dibujarProgreso(DrawContext ctx, int x, int y) {
        if (progresoAncho() <= 0) return;   // la modeladora no tiene barra
        int ancho = Math.round((progresoAncho() - 2) * handler.getProgreso());
        if (ancho <= 0) return;
        int px = x + progresoX() + 1, py = y + PROGRESO_Y + 1;
        ctx.fill(px, py, px + ancho, py + PROGRESO_ALTO - 2, acento());
    }

    /** Se llenan de abajo hacia arriba, igual que los huesos del bloque. */
    private void dibujarNiveles(DrawContext ctx, int x, int y) {
        for (int i = 0; i < canales(); i++) {
            int alto = Math.round((BARRA_ALTO - 2) * handler.getNivel(i));
            if (alto <= 0) continue;
            int bx = x + BARRA_X[i] + 1;
            int base = y + BARRA_Y + BARRA_ALTO - 1;
            ctx.fill(bx, base - alto, bx + BARRA_ANCHO - 2, base, TINTA[i]);
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        super.render(ctx, mouseX, mouseY, delta);
        drawMouseoverTooltip(ctx, mouseX, mouseY);
        tooltipBarras(ctx, mouseX, mouseY);
    }

    /** Porcentaje del canal bajo el cursor. */
    private void tooltipBarras(DrawContext ctx, int mouseX, int mouseY) {
        int x = (width - backgroundWidth) / 2;
        int y = (height - backgroundHeight) / 2;
        String[] claves = { "cyan", "magenta", "yellow", "key", "paper" };
        for (int i = 0; i < canales(); i++) {
            int bx = x + BARRA_X[i], by = y + BARRA_Y;
            if (mouseX >= bx && mouseX < bx + BARRA_ANCHO && mouseY >= by && mouseY < by + BARRA_ALTO) {
                List<Text> lineas = new ArrayList<>();
                lineas.add(Text.translatable("gui.sublimadora.canal." + claves[i]));
                lineas.add(Text.literal(Math.round(handler.getNivel(i) * 100) + " %"));
                ctx.drawTooltip(textRenderer, lineas, mouseX, mouseY);
                return;
            }
        }
    }
}
