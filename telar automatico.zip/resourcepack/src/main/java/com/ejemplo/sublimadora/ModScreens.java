package com.ejemplo.sublimadora;

import net.minecraft.client.gui.screen.ingame.HandledScreens;

/** Ata cada tipo con su pantalla. Se llama desde SublimadoraModClient. */
public final class ModScreens {
    private ModScreens() {}

    public static void register() {
        HandledScreens.register(ModScreenHandlers.GARMENT_SHAPER, GarmentShaperScreen::new);
        HandledScreens.register(ModScreenHandlers.DYE_STATION, DyeStationScreen::new);
        HandledScreens.register(ModScreenHandlers.SUBLIMATOR, SublimatorScreen::new);
    }
}
