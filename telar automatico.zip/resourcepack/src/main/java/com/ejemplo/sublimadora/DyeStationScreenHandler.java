package com.ejemplo.sublimadora;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Items;
import net.minecraft.screen.ArrayPropertyDelegate;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.slot.Slot;

public class DyeStationScreenHandler extends MaquinaScreenHandler {

    /** constructor del cliente: inventario y datos vacios, los llena la sincronizacion */
    public DyeStationScreenHandler(int syncId, PlayerInventory jugador) {
        this(syncId, jugador, new SimpleInventory(6), new ArrayPropertyDelegate(DATOS));
    }

    public DyeStationScreenHandler(int syncId, PlayerInventory jugador, Inventory inv, PropertyDelegate datos) {
        super(ModScreenHandlers.DYE_STATION, syncId, jugador, inv, datos, 6);
    }

    @Override
    protected void colocarSlotsMaquina(Inventory inv) {
        // 0 prenda cruda · 1..4 tintes CMYK · 5 prenda entintada
        addSlot(new Slot(inv, 0, 77, 20));
        addSlot(new SlotTinte(inv, 1, 77, 71, Items.CYAN_DYE, datos, TINTA_C));
        addSlot(new SlotTinte(inv, 2, 95, 71, Items.MAGENTA_DYE, datos, TINTA_M));
        addSlot(new SlotTinte(inv, 3, 113, 71, Items.YELLOW_DYE, datos, TINTA_Y));
        addSlot(new SlotTinte(inv, 4, 131, 71, Items.BLACK_DYE, datos, TINTA_K));
        addSlot(new SlotSalida(inv, 5, 149, 20));
    }
}
