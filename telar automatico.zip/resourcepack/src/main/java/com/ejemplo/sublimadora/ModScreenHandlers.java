package com.ejemplo.sublimadora;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.resource.featuretoggle.FeatureFlags;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;

/** Los tres tipos de ScreenHandler de la linea. Registrar desde SublimadoraMod#onInitialize. */
public final class ModScreenHandlers {
    private ModScreenHandlers() {}

    public static final ScreenHandlerType<GarmentShaperScreenHandler> GARMENT_SHAPER =
            new ScreenHandlerType<>(GarmentShaperScreenHandler::new, FeatureFlags.VANILLA_FEATURES);
    public static final ScreenHandlerType<DyeStationScreenHandler> DYE_STATION =
            new ScreenHandlerType<>(DyeStationScreenHandler::new, FeatureFlags.VANILLA_FEATURES);
    public static final ScreenHandlerType<SublimatorScreenHandler> SUBLIMATOR =
            new ScreenHandlerType<>(SublimatorScreenHandler::new, FeatureFlags.VANILLA_FEATURES);

    public static void register() {
        Registry.register(Registries.SCREEN_HANDLER, Identifier.of(ModBlocks.MOD_ID, "garment_shaper"), GARMENT_SHAPER);
        Registry.register(Registries.SCREEN_HANDLER, Identifier.of(ModBlocks.MOD_ID, "dye_station"), DYE_STATION);
        Registry.register(Registries.SCREEN_HANDLER, Identifier.of(ModBlocks.MOD_ID, "sublimator"), SUBLIMATOR);
    }
}
