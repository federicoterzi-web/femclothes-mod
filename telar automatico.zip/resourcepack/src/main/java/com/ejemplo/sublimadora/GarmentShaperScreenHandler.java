package com.ejemplo.sublimadora;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ArrayPropertyDelegate;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.slot.Slot;

/**
 * Modeladora: un patron de corte entra por su slot, se marca izquierda,
 * derecha o ambas y al fijarlo queda apliqué en la grilla de 3 x 3.
 * Abajo, el almacen de diseños de la maquina (27 slots); del jugador solo
 * se muestra la barra rapida.
 *
 * Slots
 *   0        patron de corte          77,42
 *   1        salida (prenda cruda)   149,20
 *   2..10    fijados, por fila        95/113/131 x  96/114/132 y
 *   11..37   almacen de diseños        8,167 · 8,185 · 8,203
 *
 * Delegado propio (la base llega hasta 13)
 *   14       lateralidad elegida: 0 izquierda · 1 derecha · 2 ambas
 *   15..23   anclaje de cada celda: 0 flecha arriba · 1 flecha abajo · -1 vacia
 */
public class GarmentShaperScreenHandler extends MaquinaScreenHandler {

    public static final int LADO = 14, ANCLAJE_0 = 15, CELDAS = 9, DATOS_SHAPER = 24;
    public static final int LADO_IZQUIERDA = 0, LADO_DERECHA = 1, LADO_AMBAS = 2;
    public static final int BOTON_IZQUIERDA = 0, BOTON_DERECHA = 1, BOTON_AMBAS = 2, BOTON_FIJAR = 3;
    public static final int SLOT_PATRON = 0, SLOT_SALIDA = 1, SLOT_FIJADO_0 = 2, SLOT_ALMACEN_0 = 11;
    public static final int SLOTS = 38;

    public GarmentShaperScreenHandler(int syncId, PlayerInventory jugador) {
        this(syncId, jugador, new SimpleInventory(SLOTS), new ArrayPropertyDelegate(DATOS_SHAPER));
    }

    public GarmentShaperScreenHandler(int syncId, PlayerInventory jugador, Inventory inv, PropertyDelegate datos) {
        super(ModScreenHandlers.GARMENT_SHAPER, syncId, jugador, inv, datos, SLOTS, DATOS_SHAPER);
    }

    @Override protected int slotsJugador() { return 9; }
    @Override protected int barraRapidaY() { return 225; }

    @Override
    protected void colocarSlotsMaquina(Inventory inv) {
        addSlot(new SlotPatron(inv, SLOT_PATRON, 77, 42));
        addSlot(new SlotSalida(inv, SLOT_SALIDA, 149, 20));
        for (int fila = 0; fila < 3; fila++)
            for (int col = 0; col < 3; col++)
                // se sacan a mano, pero solo entran por el boton Fijar
                addSlot(new SlotSalida(inv, SLOT_FIJADO_0 + fila * 3 + col, 95 + col * 18, 96 + fila * 18));
        for (int fila = 0; fila < 3; fila++)
            for (int col = 0; col < 9; col++)
                addSlot(new SlotPatron(inv, SLOT_ALMACEN_0 + fila * 9 + col, 8 + col * 18, 167 + fila * 18));
    }

    public int getLado() { return datos.get(LADO); }

    /** anclaje de la celda i (0..8): 0 arriba · 1 abajo · -1 vacia */
    public int getAnclaje(int i) { return datos.get(ANCLAJE_0 + i); }

    @Override
    public boolean onButtonClick(PlayerEntity jugador, int id) {
        switch (id) {
            case BOTON_IZQUIERDA -> datos.set(LADO, LADO_IZQUIERDA);
            case BOTON_DERECHA -> datos.set(LADO, LADO_DERECHA);
            case BOTON_AMBAS -> datos.set(LADO, LADO_AMBAS);
            case BOTON_FIJAR -> fijar();
            default -> { return false; }
        }
        sendContentUpdates();
        return true;
    }

    /**
     * Mueve el patron del slot 0 a la primera celda libre de su columna:
     * izquierda, derecha, las dos, o la del medio si la pieza no tiene lateralidad.
     * TODO: el block entity resuelve lateralidad y anclaje desde el item del patron.
     */
    private void fijar() {
        ItemStack patron = inv.getStack(SLOT_PATRON);
        if (patron.isEmpty()) return;
        boolean lateral = true;   // <- false para cuello y demas piezas centradas
        int anclaje = 0;          // <- 0 flecha arriba, 1 flecha abajo
        int[] columnas = !lateral ? new int[] { 1 }
                : getLado() == LADO_AMBAS ? new int[] { 0, 2 }
                : getLado() == LADO_DERECHA ? new int[] { 2 } : new int[] { 0 };
        for (int col : columnas) {
            for (int fila = 0; fila < 3; fila++) {
                int celda = fila * 3 + col;
                if (!inv.getStack(SLOT_FIJADO_0 + celda).isEmpty()) continue;
                inv.setStack(SLOT_FIJADO_0 + celda, patron.copyWithCount(1));
                datos.set(ANCLAJE_0 + celda, anclaje);
                patron.decrement(1);
                break;
            }
        }
    }

    /** TODO: cuando exista el item de patron, filtrar por el aca. */
    private static class SlotPatron extends Slot {
        SlotPatron(Inventory inv, int indice, int x, int y) { super(inv, indice, x, y); }
    }
}
