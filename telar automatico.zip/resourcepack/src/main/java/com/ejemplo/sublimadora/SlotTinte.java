package com.ejemplo.sublimadora;

import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.slot.Slot;

/**
 * Slot de un canal: acepta un solo tinte de vainilla y solo si la carga entera
 * entra en el tanque. Si no entra, rechaza el item (decision del brief).
 */
public class SlotTinte extends Slot {
    /** un tinte llena un cuarto de tanque */
    public static final int CARGA = 250;

    private final Item aceptado;
    private final PropertyDelegate datos;
    private final int indiceTanque;

    public SlotTinte(Inventory inv, int indiceSlot, int x, int y,
                     Item aceptado, PropertyDelegate datos, int indiceTanque) {
        super(inv, indiceSlot, x, y);
        this.aceptado = aceptado;
        this.datos = datos;
        this.indiceTanque = indiceTanque;
    }

    @Override
    public boolean canInsert(ItemStack pila) {
        return pila.isOf(aceptado)
                && datos.get(indiceTanque) + CARGA <= MaquinaScreenHandler.TANQUE_LLENO;
    }
}
