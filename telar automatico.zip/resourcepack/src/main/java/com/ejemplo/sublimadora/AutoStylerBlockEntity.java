package com.ejemplo.sublimadora;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.BlockPos;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Controlador "portico": con WORKING en true repite "trabajo" (13 s: levanta
 * cuatro apliques del alimentador y los baja en la prenda); si no, "quieto".
 */
public class AutoStylerBlockEntity extends BlockEntity implements GeoBlockEntity {
    private static final RawAnimation TRABAJO = RawAnimation.begin().thenLoop("animation.auto_styler.trabajo");
    private static final RawAnimation QUIETO = RawAnimation.begin().thenLoop("animation.auto_styler.quieto");

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public AutoStylerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.AUTO_STYLER_ENTITY, pos, state);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "portico", 4, state ->
                state.setAndContinue(getCachedState().get(AutoStylerBlock.WORKING) ? TRABAJO : QUIETO)));
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
