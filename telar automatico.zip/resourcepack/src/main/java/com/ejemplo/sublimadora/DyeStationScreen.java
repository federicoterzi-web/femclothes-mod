package com.ejemplo.sublimadora;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class DyeStationScreen extends MaquinaScreen<DyeStationScreenHandler> {
    private static final Identifier TEXTURA =
            Identifier.of(ModBlocks.MOD_ID, "textures/gui/dye_station.png");

    public DyeStationScreen(DyeStationScreenHandler handler, PlayerInventory jugador, Text titulo) {
        super(handler, jugador, titulo);
    }

    @Override protected Identifier textura() { return TEXTURA; }
    @Override protected int acento() { return 0xFF4E8C78; }
    @Override protected int canales() { return 4; }
    @Override protected int progresoX() { return 100; }
    @Override protected int progresoAncho() { return 44; }
}
