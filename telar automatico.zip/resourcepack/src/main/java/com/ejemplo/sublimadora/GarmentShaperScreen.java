package com.ejemplo.sublimadora;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * La modeladora es la mas alta de las tres (176x248): patron de corte,
 * lateralidad, boton de fijar, grilla de fijados y almacen de diseños.
 * No tiene barra de progreso ni CMYK.
 */
public class GarmentShaperScreen extends MaquinaScreen<GarmentShaperScreenHandler> {
    private static final Identifier TEXTURA =
            Identifier.of(ModBlocks.MOD_ID, "textures/gui/garment_shaper.png");

    private static final int GRILLA_X = 94, GRILLA_Y = 95, PASO = 18;
    private static final int BOTON_Y = 41, BOTON_ANCHO = 22, BOTON_ALTO = 18;
    private static final int[] BOTON_X = { 98, 120, 142 };

    public GarmentShaperScreen(GarmentShaperScreenHandler handler, PlayerInventory jugador, Text titulo) {
        super(handler, jugador, titulo);
        backgroundHeight = 248;
        playerInventoryTitle = Text.translatable("gui.sublimadora.almacen");
        playerInventoryTitleY = 155;
    }

    @Override protected Identifier textura() { return TEXTURA; }
    @Override protected int acento() { return 0xFFB06A3F; }
    @Override protected int canales() { return 0; }
    @Override protected int progresoX() { return 0; }
    @Override protected int progresoAncho() { return 0; }

    @Override
    protected void init() {
        super.init();
        String[] claves = { "izquierda", "derecha", "ambas" };
        for (int i = 0; i < 3; i++) {
            final int id = i;
            addDrawableChild(ButtonWidget.builder(Text.translatable("gui.sublimadora.lado." + claves[i]), b -> clic(id))
                    .dimensions(x + BOTON_X[i], y + BOTON_Y, BOTON_ANCHO, BOTON_ALTO)
                    .build());
        }
        addDrawableChild(ButtonWidget.builder(Text.translatable("gui.sublimadora.fijar"),
                        b -> clic(GarmentShaperScreenHandler.BOTON_FIJAR))
                .dimensions(x + 76, y + 63, 90, 14)
                .build());
    }

    private void clic(int id) {
        MinecraftClient cliente = MinecraftClient.getInstance();
        if (cliente.interactionManager != null)
            cliente.interactionManager.clickButton(handler.syncId, id);
    }

    @Override
    protected void drawBackground(DrawContext ctx, float delta, int mouseX, int mouseY) {
        super.drawBackground(ctx, delta, mouseX, mouseY);
        int px = (width - backgroundWidth) / 2, py = (height - backgroundHeight) / 2;
        marcarLadoElegido(ctx, px, py);
        dibujarAnclajes(ctx, px, py);
    }

    private void marcarLadoElegido(DrawContext ctx, int px, int py) {
        int elegido = handler.getLado();
        if (elegido < 0 || elegido > 2) return;
        ctx.drawBorder(px + BOTON_X[elegido], py + BOTON_Y, BOTON_ANCHO, BOTON_ALTO, acento());
    }

    /** La flecha del anclaje, en la esquina del slot fijado. */
    private void dibujarAnclajes(DrawContext ctx, int px, int py) {
        for (int i = 0; i < GarmentShaperScreenHandler.CELDAS; i++) {
            int anclaje = handler.getAnclaje(i);
            if (anclaje < 0) continue;
            int cx = px + GRILLA_X + (i % 3) * PASO;
            int cy = py + GRILLA_Y + (i / 3) * PASO;
            ctx.drawText(textRenderer, Text.literal(anclaje == 0 ? "\u2191" : "\u2193"),
                    cx + 12, cy + 9, acento(), false);
        }
    }
}
