package com.ejemplo.sublimadora;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class SublimatorScreen extends MaquinaScreen<SublimatorScreenHandler> {
    private static final Identifier TEXTURA =
            Identifier.of(ModBlocks.MOD_ID, "textures/gui/sublimator.png");

    public SublimatorScreen(SublimatorScreenHandler handler, PlayerInventory jugador, Text titulo) {
        super(handler, jugador, titulo);
    }

    @Override protected Identifier textura() { return TEXTURA; }
    @Override protected int acento() { return 0xFFB68235; }
    @Override protected int canales() { return 5; }
    @Override protected int progresoX() { return 100; }
    @Override protected int progresoAncho() { return 44; }
}
