package com.ejemplo.sublimadora;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

/** Registro de bloque, item y block entity type. Fabric 1.21.1. */
public final class ModBlocks {
    private ModBlocks() {}

    public static final String MOD_ID = "sublimadora";

    public static final Block SUBLIMADORA = new SublimadoraBlock(
            AbstractBlock.Settings.create()
                    .strength(2.5f, 4.0f)
                    .requiresTool()
                    .nonOpaque()                       // la tapa abierta sale del cubo
                    .sounds(BlockSoundGroup.METAL)
                    .pistonBehavior(PistonBehavior.BLOCK)
    );

    public static final BlockItem SUBLIMADORA_ITEM =
            new BlockItem(SUBLIMADORA, new Item.Settings());

    public static final BlockEntityType<SublimadoraBlockEntity> SUBLIMADORA_ENTITY =
            BlockEntityType.Builder.create(SublimadoraBlockEntity::new, SUBLIMADORA).build();

    public static final Block AUTO_STYLER = new AutoStylerBlock(
            AbstractBlock.Settings.create()
                    .strength(2.5f, 4.0f)
                    .requiresTool()
                    .nonOpaque()
                    .sounds(BlockSoundGroup.METAL)
                    .pistonBehavior(PistonBehavior.BLOCK)
    );

    public static final BlockItem AUTO_STYLER_ITEM =
            new BlockItem(AUTO_STYLER, new Item.Settings());

    public static final BlockEntityType<AutoStylerBlockEntity> AUTO_STYLER_ENTITY =
            BlockEntityType.Builder.create(AutoStylerBlockEntity::new, AUTO_STYLER).build();

    public static final Block AUTO_LOOM = new AutoLoomBlock(
            AbstractBlock.Settings.create()
                    .strength(2.5f, 4.0f)
                    .requiresTool()
                    .nonOpaque()
                    .sounds(BlockSoundGroup.METAL)
                    .pistonBehavior(PistonBehavior.BLOCK)
    );

    public static final BlockItem AUTO_LOOM_ITEM =
            new BlockItem(AUTO_LOOM, new Item.Settings());

    public static final BlockEntityType<AutoLoomBlockEntity> AUTO_LOOM_ENTITY =
            BlockEntityType.Builder.create(AutoLoomBlockEntity::new, AUTO_LOOM).build();

    public static void register() {
        Identifier auto = Identifier.of(MOD_ID, "auto_styler");
        Registry.register(Registries.BLOCK, auto, AUTO_STYLER);
        Registry.register(Registries.ITEM, auto, AUTO_STYLER_ITEM);
        Registry.register(Registries.BLOCK_ENTITY_TYPE, auto, AUTO_STYLER_ENTITY);

        Identifier telar = Identifier.of(MOD_ID, "auto_loom");
        Registry.register(Registries.BLOCK, telar, AUTO_LOOM);
        Registry.register(Registries.ITEM, telar, AUTO_LOOM_ITEM);
        Registry.register(Registries.BLOCK_ENTITY_TYPE, telar, AUTO_LOOM_ENTITY);

        Identifier id = Identifier.of(MOD_ID, "sublimadora");
        Registry.register(Registries.BLOCK, id, SUBLIMADORA);
        Registry.register(Registries.ITEM, id, SUBLIMADORA_ITEM);
        Registry.register(Registries.BLOCK_ENTITY_TYPE, id, SUBLIMADORA_ENTITY);
    }
}
