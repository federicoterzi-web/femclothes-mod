package com.ejemplo.sublimadora;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.PropertyDelegate;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.Slot;

/**
 * Base de las tres pantallas: misma retumba de slots, mismo delegado de datos.
 *
 * Cotas en pixeles de textura (ventana 176x186). El Slot se construye en
 * coordenada + 1 porque la caja dibujada mide 18 y el area util 16.
 *
 *   entrada         76,19    ->  Slot 77,20
 *   salida         148,19    ->  Slot 149,20
 *   insumos (5)     76..148  ->  Slot 77,71  95,71  113,71  131,71  149,71
 *   inventario       7,103   ->  Slot  8,104   ·  barra rapida 8,162
 */
public abstract class MaquinaScreenHandler extends ScreenHandler {

    // ── indices del PropertyDelegate ──────────────────────────────
    public static final int PROGRESO = 0, PROGRESO_MAX = 1;
    public static final int TINTA_C = 2, TINTA_M = 3, TINTA_Y = 4, TINTA_K = 5, PAPEL = 6;
    public static final int ESTADO = 7;
    /** seis teselas del diseno: indice 0..15 dentro de PALETA, o -1 si esta vacio */
    public static final int DISENO_0 = 8;
    public static final int DATOS = 14;

    public static final int ESTADO_LISTO = 0, ESTADO_TRABAJANDO = 1, ESTADO_FALTA_INSUMO = 2;
    /** los tanques viajan como enteros 0..1000 para que entren en el delegado */
    public static final int TANQUE_LLENO = 1000;

    protected final Inventory inv;
    protected final PropertyDelegate datos;
    private final int slotsMaquina;

    protected MaquinaScreenHandler(ScreenHandlerType<?> tipo, int syncId, PlayerInventory jugador,
                                   Inventory inv, PropertyDelegate datos, int slotsMaquina) {
        this(tipo, syncId, jugador, inv, datos, slotsMaquina, DATOS);
    }

    protected MaquinaScreenHandler(ScreenHandlerType<?> tipo, int syncId, PlayerInventory jugador,
                                   Inventory inv, PropertyDelegate datos, int slotsMaquina, int cantidadDatos) {
        super(tipo, syncId);
        checkSize(inv, slotsMaquina);
        checkDataCount(datos, cantidadDatos);
        this.inv = inv;
        this.datos = datos;
        this.slotsMaquina = slotsMaquina;
        inv.onOpen(jugador.player);
        colocarSlotsMaquina(inv);
        colocarInventario(jugador);
        addProperties(datos);
    }

    /** Cada maquina pone los suyos; ver las cotas del encabezado. */
    protected abstract void colocarSlotsMaquina(Inventory inv);

    /** y de la primera fila del inventario; la modeladora es mas alta y la corre. */
    protected int inventarioY() { return 104; }
    /** cuantos slots del jugador se muestran: 36, o 9 si solo va la barra rapida */
    protected int slotsJugador() { return 36; }
    protected int barraRapidaY() { return 162; }

    protected void colocarInventario(PlayerInventory jugador) {
        if (slotsJugador() == 9) {   // la modeladora usa el hueco para su almacen
            for (int col = 0; col < 9; col++)
                addSlot(new Slot(jugador, col, 8 + col * 18, barraRapidaY()));
            return;
        }
        for (int fila = 0; fila < 3; fila++)
            for (int col = 0; col < 9; col++)
                addSlot(new Slot(jugador, col + fila * 9 + 9, 8 + col * 18, inventarioY() + fila * 18));
        for (int col = 0; col < 9; col++)
            addSlot(new Slot(jugador, col, 8 + col * 18, barraRapidaY()));
    }

    // ── lectura para la pantalla ──────────────────────────────────
    public float getProgreso() {
        int max = datos.get(PROGRESO_MAX);
        return max <= 0 ? 0f : Math.min(1f, datos.get(PROGRESO) / (float) max);
    }

    /** 0=C 1=M 2=Y 3=K 4=papel, en 0..1 */
    public float getNivel(int canal) {
        return datos.get(TINTA_C + canal) / (float) TANQUE_LLENO;
    }

    public int getEstado() { return datos.get(ESTADO); }

    public int getTesela(int i) { return datos.get(DISENO_0 + i); }

    /** true si el bloque nunca produjo nada: la pantalla dibuja el fantasma. */
    public boolean disenoVacio() {
        for (int i = 0; i < 6; i++) if (getTesela(i) >= 0) return false;
        return true;
    }

    @Override
    public boolean canUse(PlayerEntity jugador) {
        return inv.canPlayerUse(jugador);
    }

    @Override
    public void onClosed(PlayerEntity jugador) {
        super.onClosed(jugador);
        inv.onClose(jugador);
    }

    @Override
    public ItemStack quickMove(PlayerEntity jugador, int indice) {
        ItemStack resultado = ItemStack.EMPTY;
        Slot slot = slots.get(indice);
        if (slot == null || !slot.hasStack()) return resultado;

        ItemStack pila = slot.getStack();
        resultado = pila.copy();
        int finInventario = slotsMaquina + slotsJugador();

        if (indice < slotsMaquina) {
            // de la maquina al jugador
            if (!insertItem(pila, slotsMaquina, finInventario, true)) return ItemStack.EMPTY;
            slot.onQuickTransfer(pila, resultado);
        } else if (!insertItem(pila, 0, slotsMaquina, false)) {
            return ItemStack.EMPTY;
        }

        if (pila.isEmpty()) slot.setStack(ItemStack.EMPTY); else slot.markDirty();
        if (pila.getCount() == resultado.getCount()) return ItemStack.EMPTY;
        slot.onTakeItem(jugador, pila);
        return resultado;
    }

    /** Slot de salida: se saca, no se mete. */
    protected static class SlotSalida extends Slot {
        public SlotSalida(Inventory inv, int indice, int x, int y) { super(inv, indice, x, y); }
        @Override public boolean canInsert(ItemStack pila) { return false; }
    }
}
