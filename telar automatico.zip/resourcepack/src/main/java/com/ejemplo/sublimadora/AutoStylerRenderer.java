package com.ejemplo.sublimadora;

import software.bernie.geckolib.renderer.GeoBlockRenderer;

public class AutoStylerRenderer extends GeoBlockRenderer<AutoStylerBlockEntity> {
    public AutoStylerRenderer() {
        super(new AutoStylerGeoModel());
    }
}
