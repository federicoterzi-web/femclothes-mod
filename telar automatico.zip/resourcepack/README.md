# Sublimadora — bloque de Minecraft (Java · GeckoLib)

Prensa térmica de sublimación, 16×16×16, con tapa abisagrada que se abre como un cofre.
Mod de **Fabric 1.21.1** con **GeckoLib 4.x**, Java 21.

## Qué hay acá

    build.gradle · settings.gradle · gradle.properties     buildscript de Loom
    src/main/resources/fabric.mod.json                     entrypoints y dependencias
    src/main/resources/pack.mcmeta                         pack_format 34 (1.21 / 1.21.1)
    src/main/resources/assets/sublimadora/geo/             sublimadora.geo.json — geometría Bedrock
    src/main/resources/assets/sublimadora/animations/      abrir · abierta · cerrar · cerrada
    src/main/resources/assets/sublimadora/textures/block/  sublimadora_atlas.png (64×64) + 13 tiles
    src/main/resources/assets/sublimadora/blockstates/     variante sin GeckoLib (open × 4 rotaciones)
    src/main/resources/assets/sublimadora/models/block/    modelos JSON de esa variante
    src/main/resources/assets/sublimadora/models/item/     modelo de inventario
    src/main/resources/assets/sublimadora/lang/            es_ar y en_us
    src/main/java/com/ejemplo/sublimadora/                 las 7 clases

No falta el gradle wrapper por capricho: corré `gradle wrapper --gradle-version 8.10`
una vez (o copiá el `gradlew` de cualquier mod tuyo) y después `./gradlew build`. El jar
sale en `build/libs/`. `src/main/resources` es un resource pack válido tal cual, así que
si solo querés la variante sin GeckoLib, zipeá esa carpeta y listo.

## Las clases

    SublimadoraMod              ModInitializer: registro + entrada en la pestaña Funcional
    SublimadoraModClient        ClientModInitializer: renderer del block entity + cutout
    ModBlocks                   bloque, BlockItem y BlockEntityType
    SublimadoraBlock            FACING + OPEN, onUse alterna la tapa, getTicker
    SublimadoraBlockEntity      GeoBlockEntity: controlador "tapa" + niveles CMYK en NBT
    SublimadoraGeoModel         geo/textura/animaciones + escala de los huesos ink_*
    SublimadoraRenderer         GeoBlockRenderer

El bloque devuelve `BlockRenderType.INVISIBLE` porque lo dibuja entero el renderer de
GeckoLib. Los `blockstates` y modelos JSON quedan igual: los usa el ítem en el
inventario y la variante sin dependencia.

## Versiones

Están en `gradle.properties`. Loom 1.8, Yarn `1.21.1+build.3`, loader 0.16.9,
Fabric API `0.115.1+1.21.1`, GeckoLib `4.7.1.2` desde el maven de Cloudsmith
(`https://dl.cloudsmith.io/public/geckolib3/geckolib/maven/`). Subí GeckoLib al último
4.x si querés — la API que usa este mod (`GeoBlockEntity`,
`AnimatableManager.ControllerRegistrar`, `setCustomAnimations`) no cambió desde 4.5.
Confirmá el número exacto en el maven antes de compilar; si no resuelve, es eso.

## GeckoLib (camino principal)

Huesos: `root` → `base` (fija) y `tapa`, con pivote en `[0, 11, 8]` — la bisagra del
borde trasero, a la altura de la plancha. La animación gira solo la tapa: −104° en
0.35 s con un leve rebase al final; `cerrar` vuelve en 0.3 s con un golpecito de
asentamiento. `cerrada` y `abierta` son las poses en loop que sostienen cada extremo.

El controlador de `SublimadoraBlockEntity` lee la propiedad `OPEN` del estado y
encadena `abrir → abierta` o `cerrar → cerrada`. Las dos quedan además registradas
como triggerable, si preferís dispararlas desde el server con
`triggerAnim("tapa", "abrir")` — hay una línea comentada en `onUse` para eso.

Para editar geometría o animación: Blockbench, modo **Bedrock Block**, abrí el
`.geo.json` y cargá el `.animation.json` en la pestaña Animate.

## Display CMYK

En el costado **oeste** (izquierdo, con el frente hacia el norte): bisel oscuro, visor
negro y cuatro barras verticales — cián, magenta, amarillo y negro — sobre riel claro.
El canal K es negro real (`#17171a`); se lee por contraste contra el riel gris claro,
no por ser blanco.

Las barras **no** son textura pintada: cada una es un hueso propio del `.geo.json`
(`ink_c`, `ink_m`, `ink_y`, `ink_k`) con el pivote en su base, y
`SublimadoraGeoModel#setCustomAnimations` les escala el eje Y con el nivel de tinta
(0 = vacía, 1 = llena). Escalar desde el pivote inferior hace que se llenen de abajo
hacia arriba; con nivel 0 el hueso se oculta.

El dato vive en el block entity: `float[] tinta` por canal, persistido en NBT y
sincronizado al cliente con `toUpdatePacket` / `toInitialChunkDataNbt`. `tick(...)`
suaviza el valor mostrado y `getNivelInterpolado` lo interpola entre ticks, así la
barra baja con transición en vez de saltar. Métodos útiles: `consumir(0.02f)` (gasta
los cuatro canales; devuelve `false` si alguno está vacío) y `setTinta(canal, 1f)`
para un cartucho nuevo. En `onUse`, cerrar la tapa cuenta como prensado y consume.

El ticker ya está enganchado: `SublimadoraBlock#getTicker` devuelve
`validateTicker(type, ModBlocks.SUBLIMADORA_ENTITY, SublimadoraBlockEntity::tick)`
en los dos lados, porque el cliente lo necesita para suavizar las barras.

## Notas

- Si la tapa abre hacia el frente en vez de hacia atrás, invertí el signo de la
  rotación en `sublimadora.animation.json` (−104 → 104).
- Ítem de inventario: el modelo JSON alcanza. Si querés el modelo GeckoLib también en
  la mano, el `BlockItem` tiene que implementar `GeoItem` y llevar su `GeoItemRenderer`.
- Para NeoForge o para otra versión de Minecraft cambian los mappings: el código está
  contra Yarn 1.21.1, no contra Mojmap.


## Atlas de texturas

`sublimadora_atlas.png` es 64×64: una grilla de 4×4 de tiles de 16×16, en este orden.
Las 13 tiles sueltas del mismo directorio son recortes de esa grilla — el modelo
GeckoLib lee el atlas, los modelos JSON leen las tiles por nombre.

    (0,0)  wood       (16,0)  wood_top   (32,0)  frame      (48,0)  panel
    (0,16) platen     (16,16) control    (32,16) vent       (48,16) shirt
    (0,32) ink_track  (16,32) ink_c      (32,32) ink_m      (48,32) ink_y
    (0,48) ink_k

Cada cara del `.geo.json` apunta al origen de su tile y declara un `uv_size` igual al
**tamaño real de esa cara** (`north`/`south` → x,y · `east`/`west` → z,y · `up`/`down`
→ x,z), con piso de 1 y techo de 16. Así la densidad de téxeles es 1:1 y una astilla
de 0.07 px muestrea un téxel en vez de estirar el tile entero — que era el bug del
export anterior. Si reexportás desde Blockbench, usá UV por cara (no *box UV*) o
volvés a pisar esto.

Consecuencia al dibujar: las tiles se muestrean **desde arriba a la izquierda**, no
completas. `wood` se recorta a 6 px (cuerpo) y 3 px (tapa), así que su veta es
uniforme en Y; `control` lleva los mandos en la región 9×3 y `vent` la rejilla en 6×5,
porque ése es el recorte que toman sus caras. `frame`, `panel` e `ink_*` son
casi planas a propósito: las usan caras de muchos tamaños distintos.

## La remera necesita cutout

`sublimadora_shirt.png` tiene la silueta de la remera recortada con alfa: manga
izquierda, cuello, manga derecha, cuerpo hasta el dobladillo. Sin *render layer* de
cutout, Minecraft rellena esos píxeles transparentes y volvés a ver el cuadrado de
11×11.

- **GeckoLib**: `GeoBlockRenderer` ya usa `entityCutoutNoCull`, no hay que tocar nada.
- **Variante JSON**: los tres modelos declaran `"render_type": "minecraft:cutout"`.
  En 1.21.4+ alcanza; en versiones anteriores el campo se ignora y hace falta
  `ItemBlockRenderTypes.setRenderLayer(ModBlocks.SUBLIMADORA, RenderType.cutout())`
  en el arranque del cliente.

## Variante sin GeckoLib

Los `blockstates` y los modelos JSON siguen ahí: `sublimadora` (cerrada) y
`sublimadora_open` (tapa parada atrás). El cambio es instantáneo, sin interpolación, y
no necesita ninguna dependencia. Usalos si querés un resource pack a secas.

## Geometría (unidades de 1/16 de bloque)

    patas          y 0–2      4 tacos de 3×2×3 en las esquinas
    zócalo         y 2–3      marco oscuro
    cuerpo         y 3–9      madera, manija al frente, rejillas a los costados
    marco sup.     y 9–10     marco oscuro
    plancha        y 10–11    base térmica, remera encima
    tapa           y 11–15.5  madera con borde oscuro, panel de control al frente
    bisagra        z 16       eje de rotación de la tapa
