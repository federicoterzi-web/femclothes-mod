# Huesos por bloque (regenerado desde blocks.js)

Atlas: **128×128**, grilla 8×8 de tiles de 16 px, uno por material. Un atlas por
bloque: `textures/block/<id>_atlas.png`. El orden de tiles está en `atlas-orden.json`
(raíz del proyecto); cada cara del geo apunta al origen de su tile con `uv_size` igual
al tamaño real de la cara (piso 1, techo 16), UV por cara, no box UV.

## garment_shaper — 99 cajas
    base        fijo
    fan         gira en Z (rejilla norte)
    cargo       traslada en X (prenda por la rampa)
    guillotine  traslada en Y (baja el filo)
    needle      traslada en Y (aguja)
    design      pantalla: el último diseño (6 teselas) — cambialas por NBT
    progress    escala en X desde el borde izquierdo (pivote en su min X)

## dye_station — 149 cajas
    base, fan, cargo, roller (gira en X), design, progress
    level_cyan/magenta/yellow/key   tinta dentro del tanque — escala Y desde la base
    ink_cyan/magenta/yellow/key     barra del panel CMYK — escala Y desde la base

## sublimator — 111 cajas
    base, fan, cargo, design, progress
    lid                             pivote [0, 11.4, 7.28] — abrir/cerrar
    ink_cyan/magenta/yellow/key     panel CMYK — escala Y desde la base
    paper                           nivel de papel (insumo nuevo) — escala Y desde la base

## wardrobe — 74 cajas
    base        fijo
    door        puerta izquierda — pivote geo [-6.8, 9.45, -7.1] (bisagra oeste), giro Y

## styling_table — 64 cajas
    base        fijo (sin huesos animables)

## mannequin — 27 cajas
    base        pedestal fijo
    turntable   plato + figura — pivote geo [0, 6, 0], giro Y. Sube a y=27.2: ocupa el bloque de arriba

## auto_styler — tapa superior (cuerpo pendiente, se copia de la línea)
    base        fijo: mesa, alimentador, pórtico, biblioteca, correas
    garment     prenda sobre la mesa (cambiable por NBT)
    placed_1..4 apliques ya puestos — escala 0 = oculto, 1 = colocado
    gantry_x    puente — traslada en X (rango −3.7 … +4.2 desde el reposo)
    gantry_z    carro, hijo de gantry_x — traslada en Z
    gantry_y    cabezal, hijo de gantry_z — baja 1.63 para colocar, 1.15 para levantar
    held        aplique agarrado, hijo de gantry_y — escala 0/1
    En el geo están anidados (x > z > y > held); en blocks.js y el visor son
    hermanos y el visor les copia la posición.
    Blancos (x,z): (−3.2,−0.6) (0,−0.6) (−1.6,1.4) (−1.6,3.0) · alimentador (2.6,4.6)

Todo lo que escala tiene el pivote en su base, así se llena de abajo hacia arriba:
en el GeoModel, `setCustomAnimations` le escribe `setScaleY(nivel)` y con nivel 0
se oculta. `progress` es igual pero en X.

## Animaciones
    garment_shaper: trabajo (guillotine · needle · cargo) · en_marcha (fan)
    dye_station:    trabajo (roller · cargo) · en_marcha (fan)
    sublimator:     abrir · abierta · cerrar · cerrada (lid) · en_marcha (fan)
    wardrobe:       abrir · abierta · cerrar · cerrada (door)
    mannequin:      girar · quieto (turntable)
    auto_styler:    trabajo (13 s, 4 apliques) · quieto — controlador "portico", lee WORKING

## Ojo
Las clases Java que hay en `src/main/java` son las del bloque viejo `sublimadora`
(un solo bloque, geo `sublimadora.geo.json`). Faltan las de los tres bloques nuevos:
`GarmentShaperBlock(+Entity+GeoModel+Renderer)`, idem `DyeStation` y `Sublimator`,
y su registro en `ModBlocks`.
